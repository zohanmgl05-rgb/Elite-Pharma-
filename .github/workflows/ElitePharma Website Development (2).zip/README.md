
  # ElitePharma Website Development

  This is a code bundle for ElitePharma Website Development. The original project is available at https://www.figma.com/design/IhM417SiuAjary5CLk5sTh/ElitePharma-Website-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  