# Pakistani Healthcare E-commerce Website

A comprehensive e-commerce platform for healthcare products and services, built with React, TypeScript, Tailwind CSS, and Supabase.

## 🚀 Features

### Frontend Features
- **Modern Healthcare E-commerce Interface** - Clean, responsive design optimized for Pakistani users
- **Multi-page Navigation** - Home, Medicines, Health Checkup, Shop, Account, etc.
- **Shopping Cart & Checkout** - Full cart functionality with persistent storage
- **Product Search & Filtering** - Advanced search with category and price filters
- **Order Tracking** - Real-time order status and tracking system
- **Prescription Upload** - Upload and manage prescriptions
- **Health Checkup Booking** - Schedule medical checkups
- **Account Management** - User profiles, order history, and settings
- **Mobile Responsive** - Optimized for mobile devices

### Backend Features
- **Supabase Edge Functions** - Serverless backend with Hono.js
- **Product Management** - Complete product catalog management
- **Order Processing** - Order creation, tracking, and management
- **Cart Persistence** - Session-based cart storage
- **Health Services** - Prescription and checkup booking APIs
- **Contact Forms** - Customer inquiry management

### Pakistani Localization
- **PKR Currency** - All pricing in Pakistani Rupees
- **Local Contact Info** - Pakistani phone numbers (+92 format)
- **Local Context** - Healthcare products relevant to Pakistani market

## 🛠️ Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS v4
- **Backend**: Supabase Edge Functions with Hono.js
- **Database**: Supabase PostgreSQL with Key-Value storage
- **UI Components**: Custom components with shadcn/ui
- **Icons**: Lucide React
- **Notifications**: Sonner

## 📁 Project Structure

```
├── App.tsx                    # Main application component
├── components/
│   ├── Header.tsx            # Navigation header
│   ├── Footer.tsx            # Site footer
│   ├── CartDrawer.tsx        # Shopping cart drawer
│   ├── SearchResults.tsx     # Search functionality
│   ├── FeaturedProducts.tsx  # Product showcase
│   ├── pages/                # Application pages
│   │   ├── ShopPage.tsx      # Product catalog
│   │   ├── CheckoutPage.tsx  # Checkout process
│   │   ├── AccountPage.tsx   # User account
│   │   └── ...
│   └── ui/                   # Reusable UI components
├── supabase/
│   └── functions/
│       └── server/
│           ├── index.tsx     # API server
│           └── kv_store.tsx  # Key-value storage utility
├── styles/
│   └── globals.css          # Global styles and Tailwind config
└── utils/
    └── supabase/
        └── info.tsx         # Supabase configuration
```

## 🔧 API Endpoints

The backend provides comprehensive REST APIs:

### Products
- `GET /make-server-140e6ebe/products` - Get all products
- `GET /make-server-140e6ebe/products/search` - Search products

### Shopping Cart
- `POST /make-server-140e6ebe/cart` - Save cart
- `GET /make-server-140e6ebe/cart/:sessionId` - Get cart

### Orders
- `POST /make-server-140e6ebe/orders` - Submit order
- `GET /make-server-140e6ebe/orders/:orderId` - Get order details
- `GET /make-server-140e6ebe/track/:trackingNumber` - Track order

### Health Services
- `POST /make-server-140e6ebe/health-checkup` - Book health checkup
- `POST /make-server-140e6ebe/prescriptions` - Upload prescription

### Support
- `POST /make-server-140e6ebe/contact` - Submit contact form

## 🎨 Design Features

- **Green Healthcare Theme** - Professional medical color scheme
- **Button Text Visibility** - Fixed styling issues for better UX
- **Mobile-First Design** - Responsive layout for all devices
- **Pakistani Context** - Culturally appropriate content and pricing

## 🚀 Deployment Ready

This application is fully deployment-ready with:
- ✅ Complete frontend functionality
- ✅ Backend API integration
- ✅ Database connectivity
- ✅ Error handling and logging
- ✅ Mobile responsiveness
- ✅ Pakistani localization

## 📝 Notes

- All components are TypeScript-based for type safety
- Supabase configuration is pre-configured
- Button text visibility issues have been resolved
- Mobile navigation is fully functional
- Cart persistence works across sessions
- All pages are connected and functional