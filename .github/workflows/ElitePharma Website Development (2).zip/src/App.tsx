import { useState } from 'react';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner@2.0.3';
import { Button } from './components/ui/button';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { ProductCategories } from './components/ProductCategories';
import { FeaturedProducts } from './components/FeaturedProducts';
import { SpecialOffers } from './components/SpecialOffers';
import { TrustIndicators } from './components/TrustIndicators';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { SearchResults } from './components/SearchResults';
import { MedicinesPage } from './components/pages/MedicinesPage';
import { HealthCheckupPage } from './components/pages/HealthCheckupPage';
import { ShopPage } from './components/pages/ShopPage';
import { UploadPrescriptionPage } from './components/pages/UploadPrescriptionPage';
import { AccountPage } from './components/pages/AccountPage';
import { CheckoutPage } from './components/pages/CheckoutPage';
import { OrderTrackingPage } from './components/pages/OrderTrackingPage';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  discount?: number;
  inStock: boolean;
  category: string;
}

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState('home');
  const [lastOrderId, setLastOrderId] = useState<string>('');
  const [lastTrackingNumber, setLastTrackingNumber] = useState<string>('');

  const handleAddToCart = (product: Product) => {
    const existingItem = cartItems.find(item => item.id === product.id);
    
    if (existingItem) {
      setCartItems(items =>
        items.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
      toast.success(`Increased ${product.name} quantity in cart`);
    } else {
      const newItem: CartItem = {
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: 1,
        image: product.image
      };
      setCartItems([...cartItems, newItem]);
      toast.success(`Added ${product.name} to cart`);
    }
  };

  const handleUpdateQuantity = (id: number, quantity: number) => {
    if (quantity === 0) {
      handleRemoveItem(id);
      return;
    }
    
    setCartItems(items =>
      items.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (id: number) => {
    const item = cartItems.find(item => item.id === id);
    setCartItems(items => items.filter(item => item.id !== id));
    if (item) {
      toast.success(`Removed ${item.name} from cart`);
    }
  };

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
    if (query.trim()) {
      setCurrentPage('search');
    }
  };

  const handleNavigation = (page: string) => {
    setCurrentPage(page);
    setSearchQuery('');
  };

  const handleOrderComplete = (orderId: string, trackingNumber: string) => {
    setLastOrderId(orderId);
    setLastTrackingNumber(trackingNumber);
    setCartItems([]); // Clear cart after successful order
    setCurrentPage('order-success');
  };

  const handleGoToCheckout = () => {
    setCurrentPage('checkout');
    setIsCartOpen(false);
  };

  const totalCartItems = cartItems.reduce((total, item) => total + item.quantity, 0);

  const renderPage = () => {
    switch (currentPage) {
      case 'medicines':
        return <MedicinesPage onAddToCart={handleAddToCart} />;
      case 'health-checkup':
        return <HealthCheckupPage />;
      case 'shop':
        return <ShopPage onAddToCart={handleAddToCart} />;
      case 'upload-prescription':
        return <UploadPrescriptionPage />;
      case 'account':
        return <AccountPage />;
      case 'checkout':
        return (
          <CheckoutPage 
            cartItems={cartItems}
            onOrderComplete={handleOrderComplete}
            onNavigateToCart={() => setIsCartOpen(true)}
          />
        );
      case 'track-order':
        return <OrderTrackingPage />;
      case 'order-success':
        return (
          <div className="py-16">
            <div className="container mx-auto px-4 text-center">
              <div className="max-w-md mx-auto">
                <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h1 className="text-2xl font-bold text-gray-900 mb-4">Order Placed Successfully!</h1>
                <p className="text-gray-600 mb-6">
                  Your order #{lastOrderId} has been confirmed. 
                  <br />Tracking Number: <strong>{lastTrackingNumber}</strong>
                </p>
                <div className="space-y-3">
                  <Button 
                    onClick={() => setCurrentPage('track-order')} 
                    className="w-full bg-green-600 hover:bg-green-700 text-white"
                  >
                    Track Your Order
                  </Button>
                  <Button 
                    onClick={() => setCurrentPage('home')} 
                    variant="outline"
                    className="w-full"
                  >
                    Continue Shopping
                  </Button>
                </div>
              </div>
            </div>
          </div>
        );
      case 'search':
        return (
          <SearchResults 
            searchQuery={searchQuery} 
            onAddToCart={handleAddToCart}
          />
        );
      case 'home':
      default:
        return (
          <>
            <HeroSection onNavigation={handleNavigation} />
            <ProductCategories />
            <FeaturedProducts onAddToCart={handleAddToCart} onNavigation={handleNavigation} />
            <SpecialOffers onNavigation={handleNavigation} />
            <TrustIndicators />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header 
        cartItemsCount={totalCartItems} 
        onSearchChange={handleSearchChange}
        onCartClick={() => setIsCartOpen(true)}
        onNavigation={handleNavigation}
        currentPage={currentPage}
      />
      
      <main>
        {renderPage()}
      </main>
      
      <Footer />
      
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onGoToCheckout={handleGoToCheckout}
      />
      
      <Toaster />
    </div>
  );
}