import { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Upload, FileText, Phone, MapPin, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export function UploadPrescriptionPage() {
  const [prescriptionFile, setPrescriptionFile] = useState<File | null>(null);
  const [uploadForm, setUploadForm] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    instructions: '',
    deliveryType: 'standard'
  });
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast.error('File size should be less than 10MB');
        return;
      }
      
      // Check file type
      const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
      if (!allowedTypes.includes(file.type)) {
        toast.error('Please upload JPG, PNG, or PDF files only');
        return;
      }
      
      setPrescriptionFile(file);
      toast.success('Prescription uploaded successfully');
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setUploadForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async () => {
    if (!prescriptionFile) {
      toast.error('Please upload your prescription first');
      return;
    }
    
    if (!uploadForm.name || !uploadForm.phone || !uploadForm.address) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsUploading(true);
    
    try {
      // Convert file to base64 for storage (in a real app, you'd upload to cloud storage)
      const fileReader = new FileReader();
      fileReader.onload = async () => {
        const fileBase64 = fileReader.result as string;
        
        const prescriptionData = {
          customerInfo: {
            name: uploadForm.name,
            phone: uploadForm.phone,
            email: uploadForm.email,
            address: uploadForm.address
          },
          fileName: prescriptionFile.name,
          fileType: prescriptionFile.type,
          fileSize: prescriptionFile.size,
          fileData: fileBase64, // In production, replace with cloud storage URL
          instructions: uploadForm.instructions,
          deliveryType: uploadForm.deliveryType
        };

        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-140e6ebe/prescriptions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify(prescriptionData)
        });

        const result = await response.json();
        
        if (result.success) {
          toast.success(`Prescription submitted successfully! Reference ID: ${result.prescriptionId}. We will contact you within 2 hours.`);
          
          // Reset form
          setPrescriptionFile(null);
          setUploadForm({
            name: '', phone: '', email: '', address: '', instructions: '', deliveryType: 'standard'
          });
        } else {
          throw new Error(result.error || 'Failed to submit prescription');
        }
      };
      
      fileReader.readAsDataURL(prescriptionFile);
    } catch (error) {
      console.error('Error submitting prescription:', error);
      toast.error('Failed to submit prescription. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Upload Prescription
          </h1>
          <p className="text-lg text-gray-600">
            Upload your doctor's prescription and get your medicines delivered to your doorstep
          </p>
        </div>

        {/* How it Works */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Upload className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">1. Upload Prescription</h3>
              <p className="text-gray-600 text-sm">
                Take a clear photo or scan of your prescription and upload it
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">2. Verification</h3>
              <p className="text-gray-600 text-sm">
                Our pharmacist will verify your prescription and contact you
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">3. Fast Delivery</h3>
              <p className="text-gray-600 text-sm">
                Get your medicines delivered to your address within hours
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Upload Section */}
          <Card>
            <CardHeader>
              <CardTitle>Upload Your Prescription</CardTitle>
              <p className="text-gray-600">
                Please ensure the prescription is clear and all details are visible
              </p>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* File Upload */}
              <div>
                <Label htmlFor="prescription">Prescription Image/PDF *</Label>
                <div className="mt-2">
                  <div className="flex items-center justify-center w-full">
                    <label
                      htmlFor="prescription-upload"
                      className="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100"
                    >
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        {prescriptionFile ? (
                          <>
                            <CheckCircle className="w-10 h-10 mb-3 text-green-500" />
                            <p className="mb-2 text-sm text-green-600 font-medium">
                              {prescriptionFile.name}
                            </p>
                            <p className="text-xs text-gray-500">
                              File size: {(prescriptionFile.size / 1024 / 1024).toFixed(2)} MB
                            </p>
                          </>
                        ) : (
                          <>
                            <Upload className="w-10 h-10 mb-3 text-gray-400" />
                            <p className="mb-2 text-sm text-gray-500">
                              <span className="font-semibold">Click to upload</span> or drag and drop
                            </p>
                            <p className="text-xs text-gray-500">
                              JPG, PNG or PDF (MAX. 10MB)
                            </p>
                          </>
                        )}
                      </div>
                      <input
                        id="prescription-upload"
                        type="file"
                        className="hidden"
                        accept=".jpg,.jpeg,.png,.pdf"
                        onChange={handleFileChange}
                      />
                    </label>
                  </div>
                </div>
              </div>

              {/* Prescription Guidelines */}
              <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-yellow-800 mb-2">Prescription Guidelines:</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Ensure prescription is from a licensed doctor</li>
                      <li>• Image should be clear and readable</li>
                      <li>• All medicine names and dosages should be visible</li>
                      <li>• Doctor's signature and stamp should be clear</li>
                      <li>• Prescription should not be older than 30 days</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Details */}
          <Card>
            <CardHeader>
              <CardTitle>Contact & Delivery Details</CardTitle>
              <p className="text-gray-600">
                Provide your details for order confirmation and delivery
              </p>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={uploadForm.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Enter your full name"
                />
              </div>
              
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  value={uploadForm.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  placeholder="+92 300 1234567"
                />
              </div>
              
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={uploadForm.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="your.email@example.com"
                />
              </div>
              
              <div>
                <Label htmlFor="address">Delivery Address *</Label>
                <Textarea
                  id="address"
                  value={uploadForm.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  placeholder="Complete delivery address with landmarks"
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="delivery-type">Delivery Type</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <label className="flex items-center space-x-2 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="radio"
                      name="deliveryType"
                      value="standard"
                      checked={uploadForm.deliveryType === 'standard'}
                      onChange={(e) => handleInputChange('deliveryType', e.target.value)}
                      className="text-green-600"
                    />
                    <div>
                      <p className="font-medium">Standard</p>
                      <p className="text-xs text-gray-600">4-6 hours</p>
                    </div>
                  </label>
                  
                  <label className="flex items-center space-x-2 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="radio"
                      name="deliveryType"
                      value="express"
                      checked={uploadForm.deliveryType === 'express'}
                      onChange={(e) => handleInputChange('deliveryType', e.target.value)}
                      className="text-green-600"
                    />
                    <div>
                      <p className="font-medium">Express</p>
                      <p className="text-xs text-gray-600">2-3 hours</p>
                    </div>
                  </label>
                </div>
              </div>
              
              <div>
                <Label htmlFor="instructions">Special Instructions</Label>
                <Textarea
                  id="instructions"
                  value={uploadForm.instructions}
                  onChange={(e) => handleInputChange('instructions', e.target.value)}
                  placeholder="Any special delivery instructions or medicine preferences"
                  rows={2}
                />
              </div>
              
              <Button
                onClick={handleSubmit}
                disabled={isUploading}
                className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-3"
                size="lg"
              >
                {isUploading ? 'Submitting...' : 'Submit Prescription'}
              </Button>
              
              <p className="text-sm text-gray-600 text-center">
                Our pharmacist will contact you within 2 hours to confirm your order
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Service Features */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-6 bg-gray-50 rounded-lg">
            <Phone className="h-8 w-8 text-green-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Expert Consultation</h3>
            <p className="text-sm text-gray-600">
              Our qualified pharmacists will verify and provide guidance
            </p>
          </div>
          
          <div className="text-center p-6 bg-gray-50 rounded-lg">
            <Clock className="h-8 w-8 text-blue-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Quick Processing</h3>
            <p className="text-sm text-gray-600">
              Fast verification and processing within 2 hours
            </p>
          </div>
          
          <div className="text-center p-6 bg-gray-50 rounded-lg">
            <MapPin className="h-8 w-8 text-purple-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Doorstep Delivery</h3>
            <p className="text-sm text-gray-600">
              Safe and secure delivery to your address
            </p>
          </div>
        </div>

        {/* Contact Information */}
        <div className="mt-8 p-6 bg-green-50 rounded-lg border border-green-200">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-green-800 mb-2">Need Help?</h3>
            <p className="text-green-700 mb-4">
              Contact our customer service for any assistance with prescription upload
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-6">
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-green-600" />
                <span className="text-green-800">+92 (21) 111-456-789</span>
              </div>
              <div className="text-green-800">Available 24/7</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}