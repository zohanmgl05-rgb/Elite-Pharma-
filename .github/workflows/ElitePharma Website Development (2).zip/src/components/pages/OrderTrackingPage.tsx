import { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { Search, Package, Truck, CheckCircle, Clock, MapPin, Phone } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface TimelineItem {
  status: string;
  completed: boolean;
  date: string | null;
}

interface Order {
  id: string;
  customerInfo: {
    firstName: string;
    lastName: string;
    phone: string;
  };
  shippingAddress: {
    address: string;
    city: string;
    province: string;
  };
  status: string;
  createdAt: string;
  estimatedDelivery: string;
  trackingNumber: string;
  total: number;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
  }>;
}

export function OrderTrackingPage() {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [orderData, setOrderData] = useState<{
    order: Order;
    timeline: TimelineItem[];
  } | null>(null);
  const [error, setError] = useState('');

  const handleTrackOrder = async () => {
    if (!trackingNumber.trim()) {
      toast.error('Please enter a tracking number');
      return;
    }

    setIsLoading(true);
    setError('');
    setOrderData(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-140e6ebe/track/${trackingNumber.trim()}`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      const result = await response.json();

      if (response.ok && result.order) {
        setOrderData(result);
        toast.success('Order found successfully!');
      } else {
        setError(result.error || 'Order not found');
        toast.error(result.error || 'Order not found with this tracking number');
      }
    } catch (error) {
      console.error('Error tracking order:', error);
      setError('Failed to track order. Please try again.');
      toast.error('Failed to track order. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'processing': return 'bg-blue-500';
      case 'shipped': return 'bg-purple-500';
      case 'delivered': return 'bg-green-500';
      case 'cancelled': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'order placed': return <Package className="h-5 w-5" />;
      case 'processing': return <Clock className="h-5 w-5" />;
      case 'shipped': return <Truck className="h-5 w-5" />;
      case 'delivered': return <CheckCircle className="h-5 w-5" />;
      default: return <Package className="h-5 w-5" />;
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('en-PK', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Track Your Order
            </h1>
            <p className="text-lg text-gray-600">
              Enter your tracking number to get real-time updates on your order
            </p>
          </div>

          {/* Tracking Input */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <Label htmlFor="tracking">Tracking Number</Label>
                  <Input
                    id="tracking"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                    placeholder="Enter your tracking number (e.g., TRK123456)"
                    className="mt-1"
                    onKeyPress={(e) => e.key === 'Enter' && handleTrackOrder()}
                  />
                </div>
                <div className="flex items-end">
                  <Button
                    onClick={handleTrackOrder}
                    disabled={isLoading}
                    className="bg-green-600 hover:bg-green-700 text-white font-medium"
                  >
                    {isLoading ? (
                      <>
                        <Clock className="h-4 w-4 mr-2 animate-spin" />
                        Tracking...
                      </>
                    ) : (
                      <>
                        <Search className="h-4 w-4 mr-2" />
                        Track Order
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Error Message */}
          {error && (
            <Card className="mb-8 border-red-200">
              <CardContent className="p-6">
                <div className="text-red-600 text-center">
                  <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <h3 className="text-lg font-semibold mb-2">Order Not Found</h3>
                  <p>{error}</p>
                  <p className="mt-2 text-sm">
                    Please check your tracking number and try again, or contact our support team.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Order Details */}
          {orderData && (
            <div className="space-y-6">
              {/* Order Status */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Order #{orderData.order.id}</CardTitle>
                    <Badge className={`${getStatusColor(orderData.order.status)} text-white`}>
                      {orderData.order.status.charAt(0).toUpperCase() + orderData.order.status.slice(1)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Order Date</p>
                      <p className="font-medium">{formatDate(orderData.order.createdAt)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Estimated Delivery</p>
                      <p className="font-medium">{formatDate(orderData.order.estimatedDelivery)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Total Amount</p>
                      <p className="font-medium text-green-600">PKR {orderData.order.total.toLocaleString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Tracking Timeline */}
              <Card>
                <CardHeader>
                  <CardTitle>Tracking Timeline</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {orderData.timeline.map((item, index) => (
                      <div key={index} className="flex items-start space-x-4">
                        <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                          item.completed 
                            ? 'bg-green-500 text-white' 
                            : 'bg-gray-200 text-gray-500'
                        }`}>
                          {getStatusIcon(item.status)}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className={`font-medium ${
                              item.completed ? 'text-green-600' : 'text-gray-500'
                            }`}>
                              {item.status}
                            </p>
                            {item.date && (
                              <p className="text-sm text-gray-600">
                                {formatDate(item.date)}
                              </p>
                            )}
                          </div>
                          
                          {item.completed && item.date && (
                            <p className="text-sm text-gray-600 mt-1">
                              Completed on {formatDate(item.date)}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Order Items */}
              <Card>
                <CardHeader>
                  <CardTitle>Order Items</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {orderData.order.items.map((item, index) => (
                      <div key={index} className="flex items-center justify-between py-2">
                        <div>
                          <p className="font-medium">{item.name}</p>
                          <p className="text-sm text-gray-600">Quantity: {item.quantity}</p>
                        </div>
                        <p className="font-medium">
                          PKR {(item.price * item.quantity).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Delivery Address & Contact */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <MapPin className="h-5 w-5 mr-2" />
                      Delivery Address
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="font-medium">
                      {orderData.order.customerInfo.firstName} {orderData.order.customerInfo.lastName}
                    </p>
                    <p className="text-gray-600 mt-1">
                      {orderData.order.shippingAddress.address}
                    </p>
                    <p className="text-gray-600">
                      {orderData.order.shippingAddress.city}, {orderData.order.shippingAddress.province}
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Phone className="h-5 w-5 mr-2" />
                      Contact Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="font-medium">Customer Support</p>
                    <p className="text-gray-600 mt-1">+92 (21) 111-456-789</p>
                    <p className="text-gray-600">support@pharmacy.pk</p>
                    <p className="text-sm text-gray-500 mt-2">
                      Available 24/7 for order assistance
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Help Section */}
          <Card className="mt-8">
            <CardContent className="p-6 text-center">
              <h3 className="text-lg font-semibold mb-2">Need Help?</h3>
              <p className="text-gray-600 mb-4">
                If you have any questions about your order, don't hesitate to contact us.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-50">
                  <Phone className="h-4 w-4 mr-2" />
                  Call Support
                </Button>
                <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-50">
                  <MapPin className="h-4 w-4 mr-2" />
                  Visit Store
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}