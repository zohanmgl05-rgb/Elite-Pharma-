import { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Star, Filter, Grid, List } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  discount?: number;
  inStock: boolean;
  category: string;
  prescription?: boolean;
}

interface MedicinesPageProps {
  onAddToCart: (product: Product) => void;
}

export function MedicinesPage({ onAddToCart }: MedicinesPageProps) {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const categories = [
    'all',
    'pain-relief',
    'antibiotics',
    'vitamins',
    'diabetes',
    'heart-health',
    'digestive',
    'skin-care'
  ];

  const products: Product[] = [
    {
      id: 1,
      name: "Panadol Extra (Pakistan)",
      price: 45,
      originalPrice: 55,
      rating: 4.8,
      reviews: 234,
      image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400",
      discount: 18,
      inStock: true,
      category: 'pain-relief'
    },
    {
      id: 2,
      name: "Brufen 400mg",
      price: 120,
      rating: 4.6,
      reviews: 187,
      image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400",
      inStock: true,
      category: 'pain-relief'
    },
    {
      id: 3,
      name: "Augmentin 625mg",
      price: 890,
      rating: 4.7,
      reviews: 156,
      image: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=400",
      inStock: true,
      category: 'antibiotics',
      prescription: true
    },
    {
      id: 4,
      name: "Centrum Multivitamin",
      price: 2150,
      originalPrice: 2400,
      rating: 4.9,
      reviews: 445,
      image: "https://images.unsplash.com/photo-1550572017-ebe0fed50ac1?w=400",
      discount: 10,
      inStock: true,
      category: 'vitamins'
    },
    {
      id: 5,
      name: "Glucophage 500mg",
      price: 185,
      rating: 4.5,
      reviews: 298,
      image: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400",
      inStock: true,
      category: 'diabetes',
      prescription: true
    },
    {
      id: 6,
      name: "Lipitor 20mg",
      price: 750,
      originalPrice: 850,
      rating: 4.6,
      reviews: 167,
      image: "https://images.unsplash.com/photo-1550572017-ebe0fed50ac1?w=400",
      discount: 12,
      inStock: true,
      category: 'heart-health',
      prescription: true
    }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Medicines</h1>
          <p className="text-lg text-gray-600">
            Browse our extensive collection of quality medicines and health products
          </p>
        </div>

        {/* Filters and View Toggle */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 space-y-4 lg:space-y-0">
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="capitalize"
              >
                {category.replace('-', ' ')}
              </Button>
            ))}
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Products Grid */}
        <div className={`grid gap-6 ${
          viewMode === 'grid' 
            ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
            : 'grid-cols-1'
        }`}>
          {filteredProducts.map(product => (
            <Card key={product.id} className="group hover:shadow-lg transition-shadow">
              <CardHeader className="p-4">
                <div className="relative">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-48 object-cover rounded-lg"
                  />
                  {product.discount && (
                    <Badge className="absolute top-2 left-2 bg-red-500 text-white">
                      -{product.discount}%
                    </Badge>
                  )}
                  {product.prescription && (
                    <Badge className="absolute top-2 right-2 bg-orange-500 text-white">
                      Rx
                    </Badge>
                  )}
                  {!product.inStock && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-lg">
                      <Badge variant="destructive">Out of Stock</Badge>
                    </div>
                  )}
                </div>
              </CardHeader>
              
              <CardContent className="p-4 pt-0">
                <CardTitle className="text-lg mb-2 line-clamp-2">{product.name}</CardTitle>
                
                <div className="flex items-center mb-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(product.rating)
                            ? 'text-yellow-400 fill-current'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600 ml-2">
                    ({product.reviews})
                  </span>
                </div>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-lg font-bold text-green-600">
                      PKR {product.price.toLocaleString()}
                    </span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-500 line-through">
                        PKR {product.originalPrice.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>
                
                <Button
                  onClick={() => onAddToCart(product)}
                  disabled={!product.inStock}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-medium"
                >
                  {product.inStock ? 'Add to Cart' : 'Out of Stock'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Prescription Note */}
        <div className="mt-12 p-6 bg-blue-50 rounded-lg border border-blue-200">
          <h3 className="text-lg font-semibold text-blue-900 mb-2">
            Prescription Medicines
          </h3>
          <p className="text-blue-800">
            Prescription medicines (marked with Rx) require a valid prescription from a licensed doctor. 
            Please upload your prescription during checkout or visit our pharmacy with the original prescription.
          </p>
        </div>
      </div>
    </div>
  );
}