import { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Calendar, Clock, MapPin, Phone, User, Heart, Activity, Shield } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface HealthPackage {
  id: number;
  name: string;
  price: number;
  originalPrice: number;
  duration: string;
  tests: string[];
  features: string[];
  recommended: boolean;
  discount: number;
}

export function HealthCheckupPage() {
  const [selectedPackage, setSelectedPackage] = useState<number | null>(null);
  const [bookingForm, setBookingForm] = useState({
    name: '',
    phone: '',
    email: '',
    age: '',
    gender: '',
    city: '',
    preferredDate: '',
    preferredTime: '',
    medicalHistory: ''
  });

  const healthPackages: HealthPackage[] = [
    {
      id: 1,
      name: "Basic Health Checkup",
      price: 4500,
      originalPrice: 6000,
      duration: "2-3 hours",
      tests: [
        "Complete Blood Count (CBC)",
        "Blood Sugar Fasting",
        "Blood Pressure Check",
        "BMI Calculation",
        "General Physical Examination"
      ],
      features: [
        "Digital Health Report",
        "Doctor Consultation",
        "Basic Lifestyle Recommendations"
      ],
      recommended: false,
      discount: 25
    },
    {
      id: 2,
      name: "Comprehensive Health Checkup",
      price: 8500,
      originalPrice: 12000,
      duration: "4-5 hours",
      tests: [
        "Complete Blood Count (CBC)",
        "Lipid Profile",
        "Liver Function Tests",
        "Kidney Function Tests",
        "Thyroid Function Tests",
        "Blood Sugar (Fasting & PP)",
        "Urine Analysis",
        "ECG",
        "Chest X-Ray"
      ],
      features: [
        "Comprehensive Digital Report",
        "Specialist Doctor Consultation",
        "Personalized Diet Plan",
        "Exercise Recommendations",
        "Follow-up Consultation"
      ],
      recommended: true,
      discount: 30
    },
    {
      id: 3,
      name: "Executive Health Checkup",
      price: 15000,
      originalPrice: 20000,
      duration: "Full Day",
      tests: [
        "All Comprehensive Package Tests",
        "Echocardiogram",
        "Stress Test",
        "Ultrasound Abdomen",
        "Bone Density Test",
        "Cancer Markers",
        "Vitamin D & B12",
        "HbA1c",
        "Eye Examination",
        "Dental Checkup"
      ],
      features: [
        "Premium Digital Report",
        "Multiple Specialist Consultations",
        "Personalized Health Plan",
        "Nutritionist Consultation",
        "3 Months Follow-up",
        "Priority Booking",
        "Home Sample Collection"
      ],
      recommended: false,
      discount: 25
    }
  ];

  const cities = [
    "Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad", 
    "Multan", "Peshawar", "Quetta", "Sialkot", "Gujranwala"
  ];

  const timeSlots = [
    "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
    "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"
  ];

  const handleInputChange = (field: string, value: string) => {
    setBookingForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleBooking = async () => {
    if (!selectedPackage || !bookingForm.name || !bookingForm.phone || !bookingForm.city) {
      toast.error('Please fill in all required fields and select a package');
      return;
    }

    const selectedPkg = healthPackages.find(pkg => pkg.id === selectedPackage);
    
    try {
      const bookingData = {
        packageId: selectedPackage,
        packageName: selectedPkg?.name,
        packagePrice: selectedPkg?.price,
        customerInfo: {
          name: bookingForm.name,
          phone: bookingForm.phone,
          email: bookingForm.email,
          age: bookingForm.age,
          gender: bookingForm.gender
        },
        location: {
          city: bookingForm.city,
        },
        preferences: {
          preferredDate: bookingForm.preferredDate,
          preferredTime: bookingForm.preferredTime,
          medicalHistory: bookingForm.medicalHistory
        }
      };

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-140e6ebe/health-checkup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify(bookingData)
      });

      const result = await response.json();
      
      if (result.success) {
        toast.success(`Health checkup booking confirmed! Booking ID: ${result.bookingId}. Package: ${selectedPkg?.name}. We'll contact you shortly.`);
        
        // Reset form
        setBookingForm({
          name: '', phone: '', email: '', age: '', gender: '', city: '',
          preferredDate: '', preferredTime: '', medicalHistory: ''
        });
        setSelectedPackage(null);
      } else {
        throw new Error(result.error || 'Failed to submit booking');
      }
    } catch (error) {
      console.error('Error submitting health checkup booking:', error);
      toast.error('Failed to submit booking. Please try again.');
    }
  };

  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Health Checkup Packages
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Take control of your health with our comprehensive health checkup packages. 
            Early detection and prevention are key to maintaining good health.
          </p>
        </div>

        {/* Benefits Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center">
            <CardContent className="p-6">
              <Heart className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Expert Care</h3>
              <p className="text-gray-600">Qualified doctors and state-of-the-art equipment</p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="p-6">
              <Activity className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Comprehensive Tests</h3>
              <p className="text-gray-600">Complete health screening with detailed reports</p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="p-6">
              <Shield className="h-12 w-12 text-blue-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Prevention Focus</h3>
              <p className="text-gray-600">Early detection and prevention strategies</p>
            </CardContent>
          </Card>
        </div>

        {/* Health Packages */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {healthPackages.map(pkg => (
            <Card 
              key={pkg.id} 
              className={`relative cursor-pointer transition-all hover:shadow-lg ${
                selectedPackage === pkg.id ? 'ring-2 ring-green-500' : ''
              } ${pkg.recommended ? 'border-green-500' : ''}`}
              onClick={() => setSelectedPackage(pkg.id)}
            >
              {pkg.recommended && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-500 text-white">
                  Most Popular
                </Badge>
              )}
              
              <CardHeader className="text-center">
                <CardTitle className="text-xl mb-2">{pkg.name}</CardTitle>
                <div className="mb-2">
                  <span className="text-3xl font-bold text-green-600">
                    PKR {pkg.price.toLocaleString()}
                  </span>
                  <span className="text-sm text-gray-500 line-through ml-2">
                    PKR {pkg.originalPrice.toLocaleString()}
                  </span>
                </div>
                <Badge variant="secondary">Save {pkg.discount}%</Badge>
                <div className="flex items-center justify-center text-gray-600 mt-2">
                  <Clock className="h-4 w-4 mr-1" />
                  <span className="text-sm">{pkg.duration}</span>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="mb-4">
                  <h4 className="font-semibold mb-2">Tests Included:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {pkg.tests.map((test, index) => (
                      <li key={index} className="flex items-start">
                        <span className="text-green-500 mr-2">✓</span>
                        {test}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Features:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <span className="text-blue-500 mr-2">★</span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Booking Form */}
        {selectedPackage && (
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-center">Book Your Health Checkup</CardTitle>
              <p className="text-center text-gray-600">
                Selected: {healthPackages.find(pkg => pkg.id === selectedPackage)?.name}
              </p>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={bookingForm.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="Enter your full name"
                  />
                </div>
                
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    value={bookingForm.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    placeholder="+92 300 1234567"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={bookingForm.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="your.email@example.com"
                  />
                </div>
                
                <div>
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    value={bookingForm.age}
                    onChange={(e) => handleInputChange('age', e.target.value)}
                    placeholder="Your age"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="gender">Gender</Label>
                  <Select onValueChange={(value) => handleInputChange('gender', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="city">City *</Label>
                  <Select onValueChange={(value) => handleInputChange('city', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your city" />
                    </SelectTrigger>
                    <SelectContent>
                      {cities.map(city => (
                        <SelectItem key={city} value={city.toLowerCase()}>
                          {city}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="preferredDate">Preferred Date</Label>
                  <Input
                    id="preferredDate"
                    type="date"
                    value={bookingForm.preferredDate}
                    onChange={(e) => handleInputChange('preferredDate', e.target.value)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="preferredTime">Preferred Time</Label>
                  <Select onValueChange={(value) => handleInputChange('preferredTime', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select time slot" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map(time => (
                        <SelectItem key={time} value={time}>
                          {time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="medicalHistory">Medical History (Optional)</Label>
                <Textarea
                  id="medicalHistory"
                  value={bookingForm.medicalHistory}
                  onChange={(e) => handleInputChange('medicalHistory', e.target.value)}
                  placeholder="Any existing medical conditions or medications..."
                  rows={3}
                />
              </div>
              
              <Button 
                onClick={handleBooking}
                className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-3"
                size="lg"
              >
                Confirm Booking - PKR {healthPackages.find(pkg => pkg.id === selectedPackage)?.price.toLocaleString()}
              </Button>
              
              <p className="text-sm text-gray-600 text-center">
                * Our team will contact you within 24 hours to confirm your appointment
              </p>
            </CardContent>
          </Card>
        )}

        {/* Contact Information */}
        <div className="mt-12 bg-gray-50 p-8 rounded-lg">
          <h3 className="text-xl font-semibold text-center mb-6">Contact Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div className="flex items-center justify-center space-x-2">
              <Phone className="h-5 w-5 text-green-600" />
              <span>+92 (21) 111-456-789</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <MapPin className="h-5 w-5 text-green-600" />
              <span>Available in major cities</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <Clock className="h-5 w-5 text-green-600" />
              <span>Mon-Fri: 8AM-6PM</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}