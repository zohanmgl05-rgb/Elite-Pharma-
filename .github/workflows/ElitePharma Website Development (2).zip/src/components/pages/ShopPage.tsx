import { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Star, Search, Filter, ShoppingCart } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  discount?: number;
  inStock: boolean;
  category: string;
  brand: string;
  description: string;
}

interface ShopPageProps {
  onAddToCart: (product: Product) => void;
}

export function ShopPage({ onAddToCart }: ShopPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [priceRange, setPriceRange] = useState('all');

  const categories = [
    { id: 'all', name: 'All Products' },
    { id: 'medicines', name: 'Medicines' },
    { id: 'vitamins', name: 'Vitamins & Supplements' },
    { id: 'personal-care', name: 'Personal Care' },
    { id: 'baby-care', name: 'Baby Care' },
    { id: 'health-devices', name: 'Health Devices' },
    { id: 'beauty', name: 'Beauty & Skincare' }
  ];

  const priceRanges = [
    { id: 'all', name: 'All Prices' },
    { id: '0-500', name: 'Under PKR 500' },
    { id: '500-1000', name: 'PKR 500 - 1,000' },
    { id: '1000-5000', name: 'PKR 1,000 - 5,000' },
    { id: '5000+', name: 'Above PKR 5,000' }
  ];

  const products: Product[] = [
    {
      id: 1,
      name: "Panadol Extra (Pack of 20)",
      price: 45,
      originalPrice: 55,
      rating: 4.8,
      reviews: 234,
      image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400",
      discount: 18,
      inStock: true,
      category: 'medicines',
      brand: 'GSK',
      description: 'Fast relief from headaches, fever and body pain'
    },
    {
      id: 2,
      name: "Centrum Multivitamin (30 tablets)",
      price: 2150,
      originalPrice: 2400,
      rating: 4.9,
      reviews: 445,
      image: "https://images.unsplash.com/photo-1550572017-ebe0fed50ac1?w=400",
      discount: 10,
      inStock: true,
      category: 'vitamins',
      brand: 'Pfizer',
      description: 'Complete daily multivitamin for adults'
    },
    {
      id: 3,
      name: "Himalaya Face Wash",
      price: 285,
      rating: 4.6,
      reviews: 187,
      image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400",
      inStock: true,
      category: 'personal-care',
      brand: 'Himalaya',
      description: 'Natural face wash for all skin types'
    },
    {
      id: 4,
      name: "Johnson's Baby Shampoo",
      price: 395,
      originalPrice: 450,
      rating: 4.7,
      reviews: 356,
      image: "https://images.unsplash.com/photo-1620706857370-e1b9770e8bb1?w=400",
      discount: 12,
      inStock: true,
      category: 'baby-care',
      brand: 'Johnson & Johnson',
      description: 'Gentle baby shampoo with no more tears formula'
    },
    {
      id: 5,
      name: "Digital Thermometer",
      price: 750,
      rating: 4.5,
      reviews: 123,
      image: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=400",
      inStock: true,
      category: 'health-devices',
      brand: 'Omron',
      description: 'Fast and accurate digital thermometer'
    },
    {
      id: 6,
      name: "Neutrogena Sunscreen SPF 50",
      price: 1850,
      originalPrice: 2100,
      rating: 4.8,
      reviews: 267,
      image: "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?w=400",
      discount: 12,
      inStock: true,
      category: 'beauty',
      brand: 'Neutrogena',
      description: 'Broad spectrum sun protection'
    },
    {
      id: 7,
      name: "Vitamin D3 (60 capsules)",
      price: 1250,
      rating: 4.6,
      reviews: 198,
      image: "https://images.unsplash.com/photo-1550572017-ebe0fed50ac1?w=400",
      inStock: true,
      category: 'vitamins',
      brand: "Nature's Bounty",
      description: 'Essential vitamin D3 for bone health'
    },
    {
      id: 8,
      name: "Blood Pressure Monitor",
      price: 4500,
      originalPrice: 5200,
      rating: 4.7,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=400",
      discount: 13,
      inStock: true,
      category: 'health-devices',
      brand: 'Omron',
      description: 'Automatic blood pressure monitor with memory'
    },
    // Personal Care Products
    {
      id: 9,
      name: "Nivea Moisturizing Cream (200ml)",
      price: 450,
      originalPrice: 520,
      rating: 4.6,
      reviews: 312,
      image: "https://images.unsplash.com/photo-1745238978251-800e5a0dbe0c?w=400",
      discount: 13,
      inStock: true,
      category: 'personal-care',
      brand: 'Nivea',
      description: 'Deep moisturizing cream for dry skin'
    },
    {
      id: 10,
      name: "Head & Shoulders Shampoo (400ml)",
      price: 850,
      rating: 4.5,
      reviews: 198,
      image: "https://images.unsplash.com/photo-1707910393340-923c5f45d899?w=400",
      inStock: true,
      category: 'personal-care',
      brand: 'Head & Shoulders',
      description: 'Anti-dandruff shampoo for healthy scalp'
    },
    {
      id: 11,
      name: "Colgate Total Toothpaste (150g)",
      price: 280,
      originalPrice: 320,
      rating: 4.7,
      reviews: 456,
      image: "https://images.unsplash.com/photo-1755086598087-771fc08e1ae5?w=400",
      discount: 12,
      inStock: true,
      category: 'personal-care',
      brand: 'Colgate',
      description: '12-hour protection against bacteria'
    },
    {
      id: 12,
      name: "Dove Beauty Bar Soap (4 Pack)",
      price: 680,
      rating: 4.8,
      reviews: 267,
      image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400",
      inStock: true,
      category: 'personal-care',
      brand: 'Dove',
      description: 'Moisturizing beauty bar with ¼ moisturizing cream'
    },
    {
      id: 13,
      name: "Pantene Hair Conditioner (400ml)",
      price: 920,
      originalPrice: 1050,
      rating: 4.6,
      reviews: 189,
      image: "https://images.unsplash.com/photo-1707910393340-923c5f45d899?w=400",
      discount: 12,
      inStock: true,
      category: 'personal-care',
      brand: 'Pantene',
      description: 'Pro-V formula for stronger, healthier hair'
    },
    {
      id: 14,
      name: "Garnier Face Wash (100ml)",
      price: 385,
      rating: 4.4,
      reviews: 156,
      image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400",
      inStock: true,
      category: 'personal-care',
      brand: 'Garnier',
      description: 'Brightening face wash for all skin types'
    },
    // Baby Care Products
    {
      id: 15,
      name: "Pampers Baby Diapers (Medium - 64 pieces)",
      price: 1850,
      originalPrice: 2100,
      rating: 4.9,
      reviews: 567,
      image: "https://images.unsplash.com/photo-1584839404042-8bc21d240e91?w=400",
      discount: 12,
      inStock: true,
      category: 'baby-care',
      brand: 'Pampers',
      description: '12-hour protection with 3 Extra Absorb Channels'
    },
    {
      id: 16,
      name: "Johnson's Baby Lotion (500ml)",
      price: 650,
      rating: 4.8,
      reviews: 423,
      image: "https://images.unsplash.com/photo-1610937146735-47e4602511c9?w=400",
      inStock: true,
      category: 'baby-care',
      brand: 'Johnson & Johnson',
      description: 'Clinically proven mild baby lotion'
    },
    {
      id: 17,
      name: "Johnson's Baby Powder (200g)",
      price: 420,
      originalPrice: 480,
      rating: 4.7,
      reviews: 298,
      image: "https://images.unsplash.com/photo-1738892248212-80f7d1f5fc94?w=400",
      discount: 12,
      inStock: true,
      category: 'baby-care',
      brand: 'Johnson & Johnson',
      description: 'Keeps baby\'s skin cool, comfortable and dry'
    },
    {
      id: 18,
      name: "Huggies Baby Wipes (80 pieces)",
      price: 485,
      rating: 4.6,
      reviews: 234,
      image: "https://images.unsplash.com/photo-1738892248212-80f7d1f5fc94?w=400",
      inStock: true,
      category: 'baby-care',
      brand: 'Huggies',
      description: 'Extra gentle baby wipes with aloe vera'
    },
    {
      id: 19,
      name: "Cerelac Baby Food (400g)",
      price: 850,
      originalPrice: 950,
      rating: 4.8,
      reviews: 189,
      image: "https://images.unsplash.com/photo-1738892248212-80f7d1f5fc94?w=400",
      discount: 10,
      inStock: true,
      category: 'baby-care',
      brand: 'Nestlé',
      description: 'Nutritious baby cereal with fruits and milk'
    },
    {
      id: 20,
      name: "Baby Dove Sensitive Moisture Soap",
      price: 320,
      rating: 4.7,
      reviews: 167,
      image: "https://images.unsplash.com/photo-1610937146735-47e4602511c9?w=400",
      inStock: true,
      category: 'baby-care',
      brand: 'Baby Dove',
      description: 'Hypoallergenic soap for sensitive baby skin'
    },
    {
      id: 21,
      name: "Farex Baby Rusk (300g)",
      price: 450,
      originalPrice: 520,
      rating: 4.5,
      reviews: 134,
      image: "https://images.unsplash.com/photo-1738892248212-80f7d1f5fc94?w=400",
      discount: 13,
      inStock: true,
      category: 'baby-care',
      brand: 'Farex',
      description: 'Nutritious baby rusk for teething babies'
    }
  ];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    
    let matchesPrice = true;
    if (priceRange !== 'all') {
      const [min, max] = priceRange.split('-').map(p => p.replace('+', ''));
      if (max) {
        matchesPrice = product.price >= parseInt(min) && product.price <= parseInt(max);
      } else {
        matchesPrice = product.price >= parseInt(min);
      }
    }
    
    return matchesSearch && matchesCategory && matchesPrice;
  });

  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Shop All Products</h1>
          <p className="text-lg text-gray-600">
            Discover our complete range of healthcare and wellness products
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <Input
              type="text"
              placeholder="Search products, brands..."
              className="pl-10 pr-4 py-3"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-1/4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="h-5 w-5 mr-2" />
                  Filters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Category Filter */}
                <div>
                  <h3 className="font-semibold mb-3">Categories</h3>
                  <div className="space-y-2">
                    {categories.map(category => (
                      <label key={category.id} className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="radio"
                          name="category"
                          value={category.id}
                          checked={selectedCategory === category.id}
                          onChange={(e) => setSelectedCategory(e.target.value)}
                          className="text-green-600"
                        />
                        <span className="text-sm">{category.name}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Price Filter */}
                <div>
                  <h3 className="font-semibold mb-3">Price Range</h3>
                  <div className="space-y-2">
                    {priceRanges.map(range => (
                      <label key={range.id} className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="radio"
                          name="price"
                          value={range.id}
                          checked={priceRange === range.id}
                          onChange={(e) => setPriceRange(e.target.value)}
                          className="text-green-600"
                        />
                        <span className="text-sm">{range.name}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Clear Filters */}
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedCategory('all');
                    setPriceRange('all');
                    setSearchQuery('');
                  }}
                  className="w-full border-green-600 text-green-600 hover:bg-green-600 hover:text-white"
                >
                  <span className="text-inherit">Clear All Filters</span>
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Products Grid */}
          <div className="lg:w-3/4">
            <div className="mb-4 flex justify-between items-center">
              <p className="text-gray-600">
                Showing {filteredProducts.length} products
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map(product => (
                <Card key={product.id} className="group hover:shadow-lg transition-shadow">
                  <CardHeader className="p-4">
                    <div className="relative">
                      <ImageWithFallback
                        src={product.image}
                        alt={product.name}
                        className="w-full h-48 object-cover rounded-lg"
                      />
                      {product.discount && (
                        <Badge className="absolute top-2 left-2 bg-red-500 text-white">
                          -{product.discount}%
                        </Badge>
                      )}
                      {!product.inStock && (
                        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-lg">
                          <Badge variant="destructive">Out of Stock</Badge>
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  
                  <CardContent className="p-4 pt-0">
                    <div className="mb-2">
                      <Badge variant="secondary" className="text-xs">
                        {product.brand}
                      </Badge>
                    </div>
                    
                    <CardTitle className="text-lg mb-2 line-clamp-2">{product.name}</CardTitle>
                    
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                      {product.description}
                    </p>
                    
                    <div className="flex items-center mb-2">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < Math.floor(product.rating)
                                ? 'text-yellow-400 fill-current'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600 ml-2">
                        ({product.reviews})
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-lg font-bold text-green-600">
                          PKR {product.price.toLocaleString()}
                        </span>
                        {product.originalPrice && (
                          <span className="text-sm text-gray-500 line-through">
                            PKR {product.originalPrice.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <Button
                      onClick={() => onAddToCart(product)}
                      disabled={!product.inStock}
                      className={`w-full font-medium ${
                        product.inStock 
                          ? 'bg-green-600 hover:bg-green-700 text-white' 
                          : 'bg-gray-400 text-gray-600'
                      }`}
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      <span className="text-inherit">
                        {product.inStock ? 'Add to Cart' : 'Out of Stock'}
                      </span>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-600 text-lg">No products found matching your criteria</p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedCategory('all');
                    setPriceRange('all');
                    setSearchQuery('');
                  }}
                  className="mt-4 border-green-600 text-green-600 hover:bg-green-600 hover:text-white"
                >
                  <span className="text-inherit">Clear Filters</span>
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Delivery Information */}
        <div className="mt-12 bg-green-50 p-6 rounded-lg border border-green-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <h3 className="font-semibold text-green-800 mb-1">Free Delivery</h3>
              <p className="text-sm text-green-700">On orders above PKR 2,000</p>
            </div>
            <div>
              <h3 className="font-semibold text-green-800 mb-1">Fast Shipping</h3>
              <p className="text-sm text-green-700">Same day delivery in major cities</p>
            </div>
            <div>
              <h3 className="font-semibold text-green-800 mb-1">Quality Assured</h3>
              <p className="text-sm text-green-700">Authentic products with warranty</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}