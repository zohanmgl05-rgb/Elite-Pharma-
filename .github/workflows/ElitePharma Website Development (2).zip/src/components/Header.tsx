import { useState } from 'react';
import { Search, ShoppingCart, User, Menu, Phone, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

interface HeaderProps {
  cartItemsCount: number;
  onSearchChange: (query: string) => void;
  onCartClick?: () => void;
  onNavigation?: (page: string) => void;
  currentPage?: string;
}

export function Header({ cartItemsCount, onSearchChange, onCartClick, onNavigation, currentPage }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    onSearchChange(query);
  };

  return (
    <header className="bg-white shadow-sm">
      {/* Top bar */}
      <div className="bg-green-600 text-white py-2">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-2">
            <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4">
              <div className="flex items-center space-x-1">
                <Phone className="h-4 w-4" />
                <span className="text-sm">+92 (21) 111-456-789</span>
              </div>
              <div className="hidden sm:flex items-center space-x-1">
                <MapPin className="h-4 w-4" />
                <span className="text-sm">Free delivery in Karachi, Lahore & Islamabad</span>
              </div>
            </div>
            <div className="text-sm text-center md:text-right">
              Welcome to ElitePharma - Pakistan's trusted online pharmacy
            </div>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col lg:flex-row items-center gap-4">
          {/* Top row: Logo and Actions */}
          <div className="flex items-center justify-between w-full lg:w-auto">
            {/* Logo */}
            <div 
              className="flex items-center space-x-2 cursor-pointer"
              onClick={() => onNavigation?.('home')}
            >
              <div className="bg-green-600 text-white p-2 rounded-lg">
                <span className="text-lg lg:text-xl font-bold">EP</span>
              </div>
              <div>
                <h1 className="text-xl lg:text-2xl font-bold text-green-600">ElitePharma</h1>
                <p className="text-xs lg:text-sm text-gray-600">Digital Pharmacy</p>
              </div>
            </div>

            {/* Mobile Actions */}
            <div className="flex items-center space-x-2 lg:hidden">
              <Button 
                variant="ghost" 
                size="sm" 
                className="relative flex items-center text-gray-700 hover:text-green-600 p-2"
                onClick={onCartClick}
              >
                <ShoppingCart className="h-5 w-5" />
                {cartItemsCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 bg-red-500 text-white text-xs px-1 min-w-[1.25rem] h-5 flex items-center justify-center rounded-full">
                    {cartItemsCount}
                  </Badge>
                )}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-700 hover:text-green-600 p-2"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Search bar */}
          <div className="w-full lg:flex-1 lg:max-w-2xl lg:mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Search for medicines, health products..."
                className="pl-10 pr-4 py-3 w-full border-gray-300 text-gray-900 placeholder:text-gray-500"
                value={searchQuery}
                onChange={handleSearchChange}
              />
            </div>
          </div>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex items-center text-gray-700 hover:text-green-600"
              onClick={() => onNavigation?.('account')}
            >
              <User className="h-5 w-5 mr-2" />
              <span>Account</span>
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="relative flex items-center text-gray-700 hover:text-green-600"
              onClick={onCartClick}
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              <span>Cart</span>
              {cartItemsCount > 0 && (
                <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-1 min-w-[1.25rem] h-5 flex items-center justify-center rounded-full">
                  {cartItemsCount}
                </Badge>
              )}
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <nav className={`mt-4 ${isMenuOpen ? 'block' : 'hidden lg:block'}`}>
          <ul className="flex flex-col lg:flex-row space-y-3 lg:space-y-0 lg:space-x-8 bg-white lg:bg-transparent p-4 lg:p-0 rounded-lg lg:rounded-none shadow-lg lg:shadow-none">
            <li>
              <button 
                onClick={() => {
                  onNavigation?.('home');
                  setIsMenuOpen(false);
                }}
                className={`block w-full text-left lg:w-auto text-gray-700 hover:text-green-600 transition-colors font-medium py-2 lg:py-0 ${
                  currentPage === 'home' ? 'text-green-600' : ''
                }`}
              >
                Home
              </button>
            </li>
            <li>
              <button 
                onClick={() => {
                  onNavigation?.('medicines');
                  setIsMenuOpen(false);
                }}
                className={`block w-full text-left lg:w-auto text-gray-700 hover:text-green-600 transition-colors font-medium py-2 lg:py-0 ${
                  currentPage === 'medicines' ? 'text-green-600' : ''
                }`}
              >
                Medicines
              </button>
            </li>
            <li>
              <button 
                onClick={() => {
                  onNavigation?.('shop');
                  setIsMenuOpen(false);
                }}
                className={`block w-full text-left lg:w-auto text-gray-700 hover:text-green-600 transition-colors font-medium py-2 lg:py-0 ${
                  currentPage === 'shop' ? 'text-green-600' : ''
                }`}
              >
                Health Products
              </button>
            </li>
            <li>
              <button 
                onClick={() => {
                  onNavigation?.('shop');
                  setIsMenuOpen(false);
                }}
                className={`block w-full text-left lg:w-auto text-gray-700 hover:text-green-600 transition-colors font-medium py-2 lg:py-0 ${
                  currentPage === 'shop' ? 'text-green-600' : ''
                }`}
              >
                Personal Care
              </button>
            </li>
            <li>
              <button 
                onClick={() => {
                  onNavigation?.('shop');
                  setIsMenuOpen(false);
                }}
                className={`block w-full text-left lg:w-auto text-gray-700 hover:text-green-600 transition-colors font-medium py-2 lg:py-0 ${
                  currentPage === 'shop' ? 'text-green-600' : ''
                }`}
              >
                Baby Care
              </button>
            </li>
            <li>
              <button 
                onClick={() => {
                  onNavigation?.('upload-prescription');
                  setIsMenuOpen(false);
                }}
                className={`block w-full text-left lg:w-auto text-gray-700 hover:text-green-600 transition-colors font-medium py-2 lg:py-0 ${
                  currentPage === 'upload-prescription' ? 'text-green-600' : ''
                }`}
              >
                Upload Prescription
              </button>
            </li>
            <li>
              <button 
                onClick={() => {
                  onNavigation?.('health-checkup');
                  setIsMenuOpen(false);
                }}
                className={`block w-full text-left lg:w-auto text-gray-700 hover:text-green-600 transition-colors font-medium py-2 lg:py-0 ${
                  currentPage === 'health-checkup' ? 'text-green-600' : ''
                }`}
              >
                Health Checkup
              </button>
            </li>
            <li>
              <button 
                onClick={() => {
                  onNavigation?.('track-order');
                  setIsMenuOpen(false);
                }}
                className={`block w-full text-left lg:w-auto text-gray-700 hover:text-green-600 transition-colors font-medium py-2 lg:py-0 ${
                  currentPage === 'track-order' ? 'text-green-600' : ''
                }`}
              >
                Track Order
              </button>
            </li>
            {/* Mobile-only Account link */}
            <li className="lg:hidden border-t border-gray-200 pt-3">
              <button 
                onClick={() => {
                  onNavigation?.('account');
                  setIsMenuOpen(false);
                }}
                className={`flex items-center w-full text-left text-gray-700 hover:text-green-600 transition-colors font-medium py-2 ${
                  currentPage === 'account' ? 'text-green-600' : ''
                }`}
              >
                <User className="h-5 w-5 mr-2" />
                Account
              </button>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}