import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface SpecialOffersProps {
  onNavigation?: (page: string) => void;
}

export function SpecialOffers({ onNavigation }: SpecialOffersProps) {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Special Offers & Deals
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Don't miss out on our exclusive deals and limited-time offers on healthcare products.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Main Deal */}
          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white overflow-hidden">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <Badge className="bg-white text-green-600 mb-4">
                    Week Deal
                  </Badge>
                  <h3 className="text-2xl font-bold mb-2">
                    Get 40% OFF on First Order
                  </h3>
                  <p className="text-green-100 mb-6">
                    Use code FIRST40 at checkout. Valid for new customers only.
                  </p>
                  <Button 
                    className="bg-white text-green-600 hover:bg-gray-100 font-semibold"
                    onClick={() => onNavigation?.('shop')}
                  >
                    <span className="text-green-600">Shop Now</span>
                  </Button>
                </div>
                <div className="hidden md:block">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1596522016734-8e6136fe5cfa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2luZSUyMHBpbGxzJTIwcGhhcm1hY3l8ZW58MXx8fHwxNzU4ODEyNTkwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="Medicine bottles"
                    className="w-32 h-32 object-cover rounded-lg opacity-80"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Secondary Deal */}
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white overflow-hidden">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <Badge className="bg-white text-blue-600 mb-4">
                    Free Delivery
                  </Badge>
                  <h3 className="text-2xl font-bold mb-2">
                    Free Shipping on Orders PKR 5,000+
                  </h3>
                  <p className="text-blue-100 mb-6">
                    Get your medicines delivered free across Pakistan.
                  </p>
                  <Button 
                    className="bg-white text-blue-600 hover:bg-gray-100 font-semibold"
                    onClick={() => onNavigation?.('shop')}
                  >
                    <span className="text-blue-600">Order Now</span>
                  </Button>
                </div>
                <div className="hidden md:block">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1595464144526-5fb181b74625?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3VwcGxpZXMlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc1ODgwMDA1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="Medical supplies"
                    className="w-32 h-32 object-cover rounded-lg opacity-80"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Promo Banner */}
        <Card className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-3xl font-bold mb-4">
              Health Checkup Package - 30% OFF
            </h3>
            <p className="text-lg text-purple-100 mb-6 max-w-3xl mx-auto">
              Complete health screening with blood tests, consultations and health reports. 
              Book your appointment today and take control of your health.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-purple-600 hover:bg-gray-100 font-semibold"
                onClick={() => onNavigation?.('health-checkup')}
              >
                <span className="text-purple-600">Book Health Checkup</span>
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-purple-600 font-semibold"
                onClick={() => onNavigation?.('health-checkup')}
              >
                <span className="text-inherit">Learn More</span>
              </Button>
            </div>
            <div className="mt-6 text-sm text-purple-200">
              *Offer valid until end of month. Terms and conditions apply.
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}