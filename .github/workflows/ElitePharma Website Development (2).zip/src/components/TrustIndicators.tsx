import { Shield, Truck, Clock, HeadphonesIcon } from 'lucide-react';
import { Card, CardContent } from './ui/card';

const features = [
  {
    icon: Shield,
    title: '100% Genuine Products',
    description: 'All medicines are sourced directly from licensed manufacturers',
    color: 'text-green-600'
  },
  {
    icon: Truck,
    title: 'Fast & Free Delivery',
    description: 'Free delivery on orders above $50, same-day delivery available',
    color: 'text-blue-600'
  },
  {
    icon: Clock,
    title: '24/7 Service',
    description: 'Round-the-clock customer support and emergency medicine delivery',
    color: 'text-purple-600'
  },
  {
    icon: HeadphonesIcon,
    title: 'Expert Consultation',
    description: 'Free consultation with qualified pharmacists and healthcare experts',
    color: 'text-orange-600'
  }
];

export function TrustIndicators() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Why Choose ElitePharma?
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            We're committed to providing you with the best healthcare experience 
            with our reliable services and quality products.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-6`}>
                  <feature.icon className={`h-8 w-8 ${feature.color}`} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Certification Badges */}
        <div className="mt-16 text-center">
          <p className="text-gray-600 mb-8">Trusted and certified by leading healthcare authorities</p>
          <div className="flex flex-wrap justify-center items-center gap-8 grayscale opacity-60">
            <div className="text-2xl font-bold text-gray-400">FDA</div>
            <div className="text-2xl font-bold text-gray-400">WHO</div>
            <div className="text-2xl font-bold text-gray-400">ISO 9001</div>
            <div className="text-2xl font-bold text-gray-400">NABP</div>
            <div className="text-2xl font-bold text-gray-400">PharmaCare</div>
          </div>
        </div>
      </div>
    </section>
  );
}