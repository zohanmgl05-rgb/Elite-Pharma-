import { Star, ShoppingCart } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  discount?: number;
  inStock: boolean;
  category: string;
}

interface FeaturedProductsProps {
  onAddToCart: (product: Product) => void;
  onNavigation?: (page: string) => void;
}

export function FeaturedProducts({ onAddToCart, onNavigation }: FeaturedProductsProps) {
  const products: Product[] = [
    {
      id: 1,
      name: 'Paracetamol 500mg Tablets',
      price: 250,
      originalPrice: 350,
      rating: 4.5,
      reviews: 128,
      image: 'https://images.unsplash.com/photo-1596522016734-8e6136fe5cfa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2luZSUyMHBpbGxzJTIwcGhhcm1hY3l8ZW58MXx8fHwxNzU4ODEyNTkwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      discount: 29,
      inStock: true,
      category: 'Pain Relief'
    },
    {
      id: 2,
      name: 'Vitamin D3 Supplements',
      price: 1200,
      originalPrice: 1500,
      rating: 4.8,
      reviews: 89,
      image: 'https://images.unsplash.com/photo-1595464144526-5fb181b74625?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3VwcGxpZXMlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc1ODgwMDA1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      discount: 20,
      inStock: true,
      category: 'Vitamins'
    },
    {
      id: 3,
      name: 'Digital Thermometer',
      price: 2500,
      rating: 4.6,
      reviews: 56,
      image: 'https://images.unsplash.com/photo-1595464144526-5fb181b74625?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3VwcGxpZXMlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc1ODgwMDA1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      inStock: true,
      category: 'Medical Devices'
    },
    {
      id: 4,
      name: 'Antiseptic Hand Gel',
      price: 450,
      originalPrice: 650,
      rating: 4.3,
      reviews: 234,
      image: 'https://images.unsplash.com/photo-1595464144526-5fb181b74625?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3VwcGxpZXMlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc1ODgwMDA1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      discount: 31,
      inStock: true,
      category: 'Personal Care'
    },
    {
      id: 5,
      name: 'Omega-3 Fish Oil',
      price: 1800,
      rating: 4.7,
      reviews: 167,
      image: 'https://images.unsplash.com/photo-1596522016734-8e6136fe5cfa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2luZSUyMHBpbGxzJTIwcGhhcm1hY3l8ZW58MXx8fHwxNzU4ODEyNTkwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      inStock: true,
      category: 'Supplements'
    },
    {
      id: 6,
      name: 'Face Masks (Pack of 50)',
      price: 950,
      originalPrice: 1400,
      rating: 4.4,
      reviews: 92,
      image: 'https://images.unsplash.com/photo-1595464144526-5fb181b74625?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3VwcGxpZXMlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc1ODgwMDA1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      discount: 32,
      inStock: true,
      category: 'Protection'
    },
    {
      id: 7,
      name: 'Blood Pressure Monitor',
      price: 8500,
      originalPrice: 10500,
      rating: 4.9,
      reviews: 45,
      image: 'https://images.unsplash.com/photo-1595464144526-5fb181b74625?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3VwcGxpZXMlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc1ODgwMDA1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      discount: 19,
      inStock: true,
      category: 'Medical Devices'
    },
    {
      id: 8,
      name: 'Multivitamin Tablets',
      price: 1350,
      rating: 4.5,
      reviews: 203,
      image: 'https://images.unsplash.com/photo-1596522016734-8e6136fe5cfa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2luZSUyMHBpbGxzJTIwcGhhcm1hY3l8ZW58MXx8fHx8MTc1ODgxMjU5MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      inStock: false,
      category: 'Vitamins'
    }
  ];

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Featured Products
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our most popular and trusted healthcare products with special offers.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="relative">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                  {product.discount && (
                    <Badge className="absolute top-2 left-2 bg-red-500 text-white">
                      -{product.discount}%
                    </Badge>
                  )}
                  {!product.inStock && (
                    <Badge className="absolute top-2 right-2 bg-gray-500 text-white">
                      Out of Stock
                    </Badge>
                  )}
                </div>
                
                <div className="p-4">
                  <div className="text-sm text-gray-500 mb-1">{product.category}</div>
                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
                    {product.name}
                  </h3>
                  
                  <div className="flex items-center mb-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(product.rating)
                              ? 'text-yellow-400 fill-current'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-500 ml-2">
                      ({product.reviews})
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-bold text-green-600">
                        PKR {product.price.toLocaleString()}
                      </span>
                      {product.originalPrice && (
                        <span className="text-sm text-gray-500 line-through">
                          PKR {product.originalPrice.toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <Button
                    className={`w-full font-semibold ${
                      product.inStock 
                        ? 'bg-green-600 hover:bg-green-700 text-white' 
                        : 'bg-gray-400 text-gray-600'
                    }`}
                    onClick={() => onAddToCart(product)}
                    disabled={!product.inStock}
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    <span className="text-inherit">{product.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button 
            variant="outline" 
            size="lg" 
            className="font-semibold border-green-600 text-green-600 hover:bg-green-600 hover:text-white"
            onClick={() => onNavigation?.('shop')}
          >
            <span>View All Products</span>
          </Button>
        </div>
      </div>
    </section>
  );
}