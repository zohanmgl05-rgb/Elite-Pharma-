import { Heart, Baby, Shield, Thermometer, Eye, Pill } from 'lucide-react';
import { Card, CardContent } from './ui/card';

const categories = [
  {
    id: 1,
    name: 'Medicines',
    icon: Pill,
    color: 'bg-blue-100 text-blue-600',
    description: 'Prescription & OTC medicines'
  },
  {
    id: 2,
    name: 'Personal Care',
    icon: Heart,
    color: 'bg-pink-100 text-pink-600',
    description: 'Skincare & beauty products'
  },
  {
    id: 3,
    name: 'Baby Care',
    icon: Baby,
    color: 'bg-yellow-100 text-yellow-600',
    description: 'Baby food & care items'
  },
  {
    id: 4,
    name: 'Health Devices',
    icon: Thermometer,
    color: 'bg-green-100 text-green-600',
    description: 'Medical devices & equipment'
  },
  {
    id: 5,
    name: 'Eye Care',
    icon: Eye,
    color: 'bg-purple-100 text-purple-600',
    description: 'Contact lenses & eye drops'
  },
  {
    id: 6,
    name: 'Immunity',
    icon: Shield,
    color: 'bg-orange-100 text-orange-600',
    description: 'Vitamins & supplements'
  }
];

export function ProductCategories() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Shop by Category
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Browse our comprehensive range of healthcare products and medicines 
            organized by categories for easy shopping.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {categories.map((category) => (
            <Card 
              key={category.id} 
              className="hover:shadow-lg transition-shadow cursor-pointer group"
            >
              <CardContent className="p-6 text-center">
                <div className={`w-16 h-16 ${category.color} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                  <category.icon className="h-8 w-8" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{category.name}</h3>
                <p className="text-sm text-gray-600">{category.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}