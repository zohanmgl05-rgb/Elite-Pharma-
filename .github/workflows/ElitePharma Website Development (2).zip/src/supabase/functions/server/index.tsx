import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-140e6ebe/health", (c) => {
  return c.json({ status: "ok" });
});

// Initialize sample data on startup
async function initializeData() {
  try {
    const existingProducts = await kv.get("products");
    if (!existingProducts) {
      const sampleProducts = [
        {
          id: 1,
          name: 'Paracetamol 500mg Tablets',
          price: 250,
          originalPrice: 350,
          rating: 4.5,
          reviews: 128,
          image: 'https://images.unsplash.com/photo-1596522016734-8e6136fe5cfa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2luZSUyMHBpbGxzJTIwcGhhcm1hY3l8ZW58MXx8fHwxNzU4ODEyNTkwfDA&ixlib=rb-4.1.0&q=80&w=1080',
          discount: 29,
          inStock: true,
          category: 'Pain Relief',
          description: 'Effective pain relief tablets for headaches, fever, and body aches.'
        },
        {
          id: 2,
          name: 'Vitamin D3 Supplements',
          price: 1200,
          originalPrice: 1500,
          rating: 4.8,
          reviews: 89,
          image: 'https://images.unsplash.com/photo-1595464144526-5fb181b74625?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3VwcGxpZXMlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc1ODgwMDA1Nnww&ixlib=rb-4.1.0&q=80&w=1080',
          discount: 20,
          inStock: true,
          category: 'Vitamins',
          description: 'Essential vitamin D3 for bone health and immune system support.'
        }
      ];
      
      await kv.set("products", sampleProducts);
      console.log("Sample products initialized");
    }
  } catch (error) {
    console.error("Error initializing data:", error);
  }
}

// Initialize data
initializeData();

// Get all products
app.get("/make-server-140e6ebe/products", async (c) => {
  try {
    const products = await kv.get("products") || [];
    return c.json({ products });
  } catch (error) {
    console.error("Error fetching products:", error);
    return c.json({ error: "Failed to fetch products" }, 500);
  }
});

// Search products
app.get("/make-server-140e6ebe/products/search", async (c) => {
  try {
    const query = c.req.query("q")?.toLowerCase() || "";
    const category = c.req.query("category") || "";
    
    const allProducts = await kv.get("products") || [];
    
    let filtered = allProducts.filter((product: any) =>
      product.name.toLowerCase().includes(query) ||
      product.category.toLowerCase().includes(query)
    );
    
    if (category && category !== "All") {
      filtered = filtered.filter((product: any) => product.category === category);
    }
    
    return c.json({ products: filtered, total: filtered.length });
  } catch (error) {
    console.error("Error searching products:", error);
    return c.json({ error: "Failed to search products" }, 500);
  }
});

// Save cart (session-based)
app.post("/make-server-140e6ebe/cart", async (c) => {
  try {
    const { sessionId, cartItems } = await c.req.json();
    
    if (!sessionId) {
      return c.json({ error: "Session ID required" }, 400);
    }
    
    await kv.set(`cart:${sessionId}`, cartItems);
    return c.json({ success: true });
  } catch (error) {
    console.error("Error saving cart:", error);
    return c.json({ error: "Failed to save cart" }, 500);
  }
});

// Get cart
app.get("/make-server-140e6ebe/cart/:sessionId", async (c) => {
  try {
    const sessionId = c.req.param("sessionId");
    const cartItems = await kv.get(`cart:${sessionId}`) || [];
    return c.json({ cartItems });
  } catch (error) {
    console.error("Error fetching cart:", error);
    return c.json({ error: "Failed to fetch cart" }, 500);
  }
});

// Submit order
app.post("/make-server-140e6ebe/orders", async (c) => {
  try {
    const orderData = await c.req.json();
    const orderId = `ORD${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    
    const order = {
      id: orderId,
      ...orderData,
      createdAt: new Date().toISOString(),
      status: 'pending',
      estimatedDelivery: new Date(Date.now() + (3 * 24 * 60 * 60 * 1000)).toISOString(), // 3 days from now
      trackingNumber: `TRK${Date.now()}${Math.random().toString(36).substr(2, 4).toUpperCase()}`
    };
    
    // Save order
    await kv.set(`order:${orderId}`, order);
    
    // Add to orders list
    const orders = await kv.get("orders") || [];
    orders.push(orderId);
    await kv.set("orders", orders);
    
    // Clear cart after successful order
    if (orderData.sessionId) {
      await kv.del(`cart:${orderData.sessionId}`);
    }
    
    return c.json({ orderId, trackingNumber: order.trackingNumber, success: true });
  } catch (error) {
    console.error("Error submitting order:", error);
    return c.json({ error: "Failed to submit order" }, 500);
  }
});

// Get order by ID
app.get("/make-server-140e6ebe/orders/:orderId", async (c) => {
  try {
    const orderId = c.req.param("orderId");
    const order = await kv.get(`order:${orderId}`);
    
    if (!order) {
      return c.json({ error: "Order not found" }, 404);
    }
    
    return c.json({ order });
  } catch (error) {
    console.error("Error fetching order:", error);
    return c.json({ error: "Failed to fetch order" }, 500);
  }
});

// Track order by tracking number
app.get("/make-server-140e6ebe/track/:trackingNumber", async (c) => {
  try {
    const trackingNumber = c.req.param("trackingNumber");
    const orders = await kv.get("orders") || [];
    
    let foundOrder = null;
    for (const orderId of orders) {
      const order = await kv.get(`order:${orderId}`);
      if (order && order.trackingNumber === trackingNumber) {
        foundOrder = order;
        break;
      }
    }
    
    if (!foundOrder) {
      return c.json({ error: "Order not found with this tracking number" }, 404);
    }
    
    // Generate tracking timeline based on order status
    const timeline = [
      { status: 'Order Placed', completed: true, date: foundOrder.createdAt },
      { status: 'Processing', completed: foundOrder.status !== 'pending', date: foundOrder.status !== 'pending' ? new Date(new Date(foundOrder.createdAt).getTime() + (24 * 60 * 60 * 1000)).toISOString() : null },
      { status: 'Shipped', completed: ['shipped', 'delivered'].includes(foundOrder.status), date: ['shipped', 'delivered'].includes(foundOrder.status) ? new Date(new Date(foundOrder.createdAt).getTime() + (48 * 60 * 60 * 1000)).toISOString() : null },
      { status: 'Delivered', completed: foundOrder.status === 'delivered', date: foundOrder.status === 'delivered' ? foundOrder.estimatedDelivery : null }
    ];
    
    return c.json({ order: foundOrder, timeline });
  } catch (error) {
    console.error("Error tracking order:", error);
    return c.json({ error: "Failed to track order" }, 500);
  }
});

// Submit health checkup booking
app.post("/make-server-140e6ebe/health-checkup", async (c) => {
  try {
    const bookingData = await c.req.json();
    const bookingId = `HCB${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    
    const booking = {
      id: bookingId,
      ...bookingData,
      createdAt: new Date().toISOString(),
      status: 'confirmed',
      appointmentDate: bookingData.preferredDate,
      appointmentTime: bookingData.preferredTime
    };
    
    // Save booking
    await kv.set(`booking:${bookingId}`, booking);
    
    // Add to bookings list
    const bookings = await kv.get("bookings") || [];
    bookings.push(bookingId);
    await kv.set("bookings", bookings);
    
    return c.json({ bookingId, success: true });
  } catch (error) {
    console.error("Error submitting health checkup booking:", error);
    return c.json({ error: "Failed to submit booking" }, 500);
  }
});

// Upload prescription
app.post("/make-server-140e6ebe/prescriptions", async (c) => {
  try {
    const prescriptionData = await c.req.json();
    const prescriptionId = `RX${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    
    const prescription = {
      id: prescriptionId,
      ...prescriptionData,
      createdAt: new Date().toISOString(),
      status: 'pending_review'
    };
    
    // Save prescription
    await kv.set(`prescription:${prescriptionId}`, prescription);
    
    // Add to prescriptions list
    const prescriptions = await kv.get("prescriptions") || [];
    prescriptions.push(prescriptionId);
    await kv.set("prescriptions", prescriptions);
    
    return c.json({ prescriptionId, success: true });
  } catch (error) {
    console.error("Error uploading prescription:", error);
    return c.json({ error: "Failed to upload prescription" }, 500);
  }
});

// Contact form submission
app.post("/make-server-140e6ebe/contact", async (c) => {
  try {
    const contactData = await c.req.json();
    const contactId = `CTT${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    
    const contact = {
      id: contactId,
      ...contactData,
      createdAt: new Date().toISOString(),
      status: 'new'
    };
    
    // Save contact
    await kv.set(`contact:${contactId}`, contact);
    
    // Add to contacts list
    const contacts = await kv.get("contacts") || [];
    contacts.push(contactId);
    await kv.set("contacts", contacts);
    
    return c.json({ contactId, success: true });
  } catch (error) {
    console.error("Error submitting contact form:", error);
    return c.json({ error: "Failed to submit contact form" }, 500);
  }
});

Deno.serve(app.fetch);